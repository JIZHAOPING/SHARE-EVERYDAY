import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { QingganPage } from './qinggan';

@NgModule({
  declarations: [
    QingganPage,
  ],
  imports: [
    IonicPageModule.forChild(QingganPage),
  ],
})
export class QingganPageModule {}
