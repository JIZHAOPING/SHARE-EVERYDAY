import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { HuozanPage } from './huozan';

@NgModule({
  declarations: [
    HuozanPage,
  ],
  imports: [
    IonicPageModule.forChild(HuozanPage),
  ],
})
export class HuozanPageModule {}
