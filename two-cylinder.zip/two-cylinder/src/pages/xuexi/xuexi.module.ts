import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { XuexiPage } from './xuexi';

@NgModule({
  declarations: [
    XuexiPage,
  ],
  imports: [
    IonicPageModule.forChild(XuexiPage),
  ],
})
export class XuexiPageModule {}
