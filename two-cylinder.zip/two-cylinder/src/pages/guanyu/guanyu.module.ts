import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { GuanyuPage } from './guanyu';

@NgModule({
  declarations: [
    GuanyuPage,
  ],
  imports: [
    IonicPageModule.forChild(GuanyuPage),
  ],
})
export class GuanyuPageModule {}
