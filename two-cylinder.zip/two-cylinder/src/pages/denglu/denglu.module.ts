import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DengluPage } from './denglu';

@NgModule({
  declarations: [
    DengluPage,
  ],
  imports: [
    IonicPageModule.forChild(DengluPage),
  ],
})
export class DengluPageModule {}
