import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { XieyiPage } from './xieyi';

@NgModule({
  declarations: [
    XieyiPage,
  ],
  imports: [
    IonicPageModule.forChild(XieyiPage),
  ],
})
export class XieyiPageModule {}
