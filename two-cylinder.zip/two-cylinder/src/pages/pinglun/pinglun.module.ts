import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PinglunPage } from './pinglun';

@NgModule({
  declarations: [
    PinglunPage,
  ],
  imports: [
    IonicPageModule.forChild(PinglunPage),
  ],
})
export class PinglunPageModule {}
