import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { FabiaoPage } from './fabiao';

@NgModule({
  declarations: [
    FabiaoPage,
  ],
  imports: [
    IonicPageModule.forChild(FabiaoPage),
  ],
})
export class FabiaoPageModule {}
