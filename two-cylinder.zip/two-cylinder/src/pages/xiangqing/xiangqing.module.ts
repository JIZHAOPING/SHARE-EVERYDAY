import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { XiangqingPage } from './xiangqing';

@NgModule({
  declarations: [
    XiangqingPage,
  ],
  imports: [
    IonicPageModule.forChild(XiangqingPage),
  ],
})
export class XiangqingPageModule {}
